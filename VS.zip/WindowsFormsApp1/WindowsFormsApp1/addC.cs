﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsApp1.samDataSetTableAdapters;
using System.Windows.Forms;

namespace WindowsFormsApp1
{

    public partial class addC : Form

    {
        private SqlConnection sqlConnection = null;
        private DataSet dataSet = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private bool newRowAdding = false;
        private SqlCommandBuilder sqlBuilder = null;
        private DataTable dt = new DataTable();
        public addC()
        {
            InitializeComponent();
            this.BackColor = Color.DarkOliveGreen;
            sqlConnection = new SqlConnection(@"Data Source = PRO_SPRINT_M\SQLEXPRESS; Initial Catalog = sam; User = Student; Password = 1234; Integrated Security = True; Encrypt = True; TrustServerCertificate = True");
            sqlConnection.Open();

            if (data.buf == "add")
            {
                button1.Text = "Добавить";
                this.Text = "Добавить запись";
            }
            else if (data.buf == "edit")
            {
                button1.Text = "Изменить";
                this.Text = "Изменить запись";
                SqlDataAdapter sda = new SqlDataAdapter("Select * From FaultTypes WHERE ID = '" + data.idIndex + "'", sqlConnection);
                sda.Fill(dt);
                int i = 0;
                textBox1.Text = dt.Rows[0][1].ToString();
                textBox2.Text = dt.Rows[0][2].ToString();


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "Изменить")
            {
                if (textBox1.Text == "" || textBox2.Text == "")
                {
                    MessageBox.Show("Пожалуйста заполните все поля!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("UPDATE FaultTypes SET Name = '" + textBox1.Text + "', Description = '" + textBox2.Text + "' WHERE ID = '" + data.idIndex + "'", sqlConnection);
                    cmd.Parameters.AddWithValue("Name", textBox1.Text);

                    cmd.ExecuteNonQuery();
                    Form4 form4 = new Form4();
                    MessageBox.Show("Запись изменена");
                    form4.Show();
                    this.Close();
                }
            }
            if (button1.Text == "Добавить")
            {
                if (textBox1.Text.ToString() == "" || textBox2.Text.ToString() == "")
                {
                    MessageBox.Show("Пожалуйста, заполните все поля!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("insert into [FaultTypes] (Name, Description)" +
                        "values (@Name, @Description)", sqlConnection);
                    cmd.Parameters.AddWithValue("Name", textBox1.Text);
                    cmd.Parameters.AddWithValue("Description", textBox2.Text);

                    cmd.ExecuteNonQuery();
                    textBox1.Text = "";
                    textBox2.Text = "";

                    MessageBox.Show("Запись добавлена");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            Close();
        }
    }
}
