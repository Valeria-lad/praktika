﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp1
{
    public partial class Form7 : Form
    {

        private SqlConnection sqlConnection = null;
        private DataSet dataSet = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private bool newRowAdding = false;
        private SqlCommandBuilder sqlBuilder = null;
        private DataTable dt = new DataTable();
       

        public Form7()
        {
            InitializeComponent();
            this.BackColor = Color.DarkSeaGreen;
            sqlConnection = new SqlConnection(@"Data Source = PRO_SPRINT_M\SQLEXPRESS; Initial Catalog = sam; User = Student; Password = 1234; Integrated Security = True; Encrypt = True; TrustServerCertificate = True");
            sqlConnection.Open();



        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "samDataSet1.Requests". При необходимости она может быть перемещена или удалена.
            this.requestsTableAdapter1.Fill(this.samDataSet1.Requests);
            

        }

        private void button2_Click(object sender, EventArgs e)
        {

            data.buf = "add";
            addF addF = new addF();
            addF.Show();
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            data.buf = "edit";
            addF addF = new addF();
            addF.Show();
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(data.idIndex))
            {
                MessageBox.Show("Пожалуйста, выберите заявку для удаления.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult dialogResult = MessageBox.Show("Удалить запись?", "Удаление", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                string deleteQuery = "DELETE FROM Requests WHERE ID = @ID";

                try
                {
                    using (SqlCommand cmd = new SqlCommand(deleteQuery, sqlConnection))
                    {
                        cmd.Parameters.AddWithValue("@ID", data.idIndex);
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Запись удалена");

                            this.requestsTableAdapter1.Fill(this.samDataSet1.Requests);
                        }
                        else
                        {
                            MessageBox.Show("Запись не найдена или уже удалена.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void equipmentDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                String str = equipmentDataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
                String idIndex = equipmentDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                data.idIndex = idIndex;
                int i = 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string searchText = textBox1.Text.Trim();

            if (string.IsNullOrWhiteSpace(searchText))
            {
                // Показать все записи, если строка поиска пуста
                this.requestsTableAdapter.Fill(this.samDataSet3.Requests);
                return;
            }

            string query = "SELECT * FROM Requests WHERE CAST(ID AS NVARCHAR) LIKE @search OR [RequestNumber] LIKE @search";

            try
            {
                if (sqlConnection.State != ConnectionState.Open)
                    sqlConnection.Open();

                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@search", "%" + searchText + "%");
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    equipmentDataGridView.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при поиске: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(data.idIndex))
            {
                MessageBox.Show("Пожалуйста, выберите заявку для добавления комментария.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string comment = richTextBox1.Text.Trim();

            if (string.IsNullOrWhiteSpace(comment))
            {
                MessageBox.Show("Введите комментарий.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Обновляем базу данных: предполагается, что есть поле Comments в таблице Requests
            string updateQuery = "UPDATE Requests SET Comments = ISNULL(Comments, '') + CHAR(13) + @comment WHERE ID = @ID";

            try
            {
                using (SqlCommand cmd = new SqlCommand(updateQuery, sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@comment", comment);
                    cmd.Parameters.AddWithValue("@ID", data.idIndex);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Комментарий добавлен.");

                        // Обновляем отображение комментариев
                        LoadComments();
                        richTextBox1.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Заявка не найдена.", "Ошибка");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении комментария: {ex.Message}", "Ошибка");
            }
        }
        private void LoadComments()
        {
            if (string.IsNullOrWhiteSpace(data.idIndex))
                return;

            string selectQuery = "SELECT Comments FROM Requests WHERE ID = @ID";

            try
            {
                using (SqlCommand cmd = new SqlCommand(selectQuery, sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@ID", data.idIndex);
                    object result = cmd.ExecuteScalar();

                    if (result != DBNull.Value && result != null)
                    {
                        richTextBox1.Text = result.ToString();
                    }
                    else
                    {
                        richTextBox1.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке комментариев: {ex.Message}", "Ошибка");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ShowStatistics();
        }
        private void ShowStatistics()
        {
            try
            {
                // Количество выполненных заявок
                string countCompletedRequestsQuery = @"
            SELECT COUNT(*) FROM Requests WHERE StatusID = 'Выполнена'";

                // Среднее время выполнения заявки (в днях)
                string avgCompletionTimeQuery = @"
            SELECT AVG(DATEDIFF(day, DateCreated, DateCompleted))
            FROM Requests
            WHERE StatusID = 'Выполнена' AND DateCreated IS NOT NULL AND DateCompleted IS NOT NULL";

                // Статистика по типам неисправностей
                string faultTypeStatsQuery = @"
            SELECT FaultType, COUNT(*) AS Count 
            FROM Requests 
            GROUP BY FaultType";

                using (SqlCommand cmdCount = new SqlCommand(countCompletedRequestsQuery, sqlConnection))
                using (SqlCommand cmdAvgTime = new SqlCommand(avgCompletionTimeQuery, sqlConnection))
                using (SqlCommand cmdFaultStats = new SqlCommand(faultTypeStatsQuery, sqlConnection))
                {
                    int completedCount = (int)cmdCount.ExecuteScalar();
                    object avgTimeObj = cmdAvgTime.ExecuteScalar();
                    string avgTimeStr = avgTimeObj != DBNull.Value ? avgTimeObj.ToString() : "Нет данных";

                    // Статистика по типам неисправностей
                    DataTable faultStatsTable = new DataTable();
                    using (SqlDataReader reader = cmdFaultStats.ExecuteReader())
                    {
                        faultStatsTable.Load(reader);
                    }

                    // Формируем строку с результатами
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine($"Количество выполненных заявок: {completedCount}");
                    sb.AppendLine($"Среднее время выполнения заявки: {avgTimeStr} дней");
                    sb.AppendLine("Статистика по типам неисправностей:");

                    foreach (DataRow row in faultStatsTable.Rows)
                    {
                        string faultType = row["FaultType"].ToString();
                        int count = Convert.ToInt32(row["Count"]);
                        sb.AppendLine($" - {faultType}: {count}");
                    }

                    MessageBox.Show(sb.ToString(), "Статистика работы отдела");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при получении статистики: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
    
    

