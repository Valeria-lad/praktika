﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.samDataSetTableAdapters;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class addA : Form
    {
        private SqlConnection sqlConnection = null;
        private DataSet dataSet = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private bool newRowAdding = false;
        private SqlCommandBuilder sqlBuilder = null;
        private DataTable dt = new DataTable();
        public addA()
        {
            InitializeComponent();
            this.BackColor = Color.DarkOliveGreen;
            sqlConnection = new SqlConnection(@"Data Source = PRO_SPRINT_M\SQLEXPRESS; Initial Catalog = sam;User = Student; Password = 1234; Integrated Security = True; Encrypt = True; TrustServerCertificate = True");
            sqlConnection.Open();

            

            if (data.buf == "add")
            {
                button1.Text = "Добавить";
                this.Text = "Добавить запись";
            }
            else if (data.buf == "edit")
            {
                button1.Text = "Изменить";
                this.Text = "Изменить запись";
                SqlDataAdapter sda = new SqlDataAdapter("Select * From Users where ID = '" + data.idIndex + "'", sqlConnection);
                sda.Fill(dt);
                int i = 0;
                textBox6.Text = dt.Rows[0][1].ToString();    
                textBox7.Text = dt.Rows[0][2].ToString();   
                textBox8.Text = dt.Rows[0][3].ToString();
                textBox1.Text = dt.Rows[0][4].ToString();
                textBox3.Text = dt.Rows[0][5].ToString();
                dateTimePicker1.Text = dt.Rows[0][6].ToString();


            }
        }
        private void button3_Click(object sender, EventArgs e)
        {

            Form2 form2 = new Form2();
            form2.Show();
            Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (button1.Text == "Изменить")
            {
                if (textBox1.Text == "")
                {
                    MessageBox.Show("Пожалуйста заполните все поля!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("UPDATE Users SET UserName = '" + textBox6.Text + "' Role = '" + textBox7.Text + "' Login = '" + textBox8.Text + "' PasswordHash = '" + textBox1.Text + "' Phone = '" + textBox3.Text + "' CreatedAt = '" + dateTimePicker1.Value.ToString() + "' WHERE ID = '" + data.idIndex + "'", sqlConnection);
                    cmd.Parameters.AddWithValue("UserName", textBox1.Text);

                    cmd.ExecuteNonQuery();
                    Form2 form2 = new Form2();
                    MessageBox.Show("Запись изменена");
                    form2.Show();
                    this.Close();
                }
            }
            if (button1.Text == "Добавить")
            {
                if (textBox1.Text.ToString() == "")
                {
                    MessageBox.Show("Пожалуйста, заполните все поля!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("insert into [Users] (UserName, Role, Login, PasswordHash, Phone, CreatedAt)" +
                        "values (@UserName, @Role, @Login, @PasswordHash, @Phone, @CreatedAt)", sqlConnection);
                    cmd.Parameters.AddWithValue("UserName", textBox6.Text);
                    cmd.Parameters.AddWithValue("Role", textBox7.Text);
                    cmd.Parameters.AddWithValue("Login", textBox8.Text);
                    cmd.Parameters.AddWithValue("PasswordHash", textBox1.Text);
                    cmd.Parameters.AddWithValue("Phone", textBox3.Text);
                    cmd.Parameters.AddWithValue("CreatedAt", SqlDbType.Date).Value = dateTimePicker1.Value.Date;


                    cmd.ExecuteNonQuery();
                    textBox6.Text = "";
                    textBox7.Text = "";
                    textBox8.Text = "";
                    textBox1.Text = "";
                    textBox3.Text = "";
                    dateTimePicker1.Text = "";

                    MessageBox.Show("Запись добавлена");
                }


            }
        }

     
    }
}


