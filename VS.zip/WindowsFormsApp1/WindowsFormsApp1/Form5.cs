﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        private SqlConnection sqlConnection = null;
        private DataSet dataSet = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private bool newRowAdding = false;
        private SqlCommandBuilder sqlBuilder = null;
        private DataTable dt = new DataTable();
     

        public Form5()
        {
            InitializeComponent();
            this.BackColor = Color.DarkSeaGreen;
            sqlConnection = new SqlConnection(@"Data Source = PRO_SPRINT_M\SQLEXPRESS; Initial Catalog = sam; User = Student; Password = 1234; Integrated Security = True; Encrypt = True; TrustServerCertificate = True");
            sqlConnection.Open();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            data.buf = "add";
            addD addD = new addD();
            addD.Show();
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            data.buf = "edit";
            addD addD = new addD();
            addD.Show();
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (data.idIndex != "")
            {
                DialogResult dialogResult = MessageBox.Show("Удалить запись?", "Удаление", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    SqlCommand cmd = new SqlCommand("DELETE Clients WHERE ID = '" + data.idIndex + "'", sqlConnection);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Запись удалена");
                    this.clientsTableAdapter.Fill(this.samDataSet3.Clients);



                }
                else if (dialogResult == DialogResult.No)
                {
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите клиента", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "samDataSet3.Clients". При необходимости она может быть перемещена или удалена.
            this.clientsTableAdapter.Fill(this.samDataSet3.Clients);

        }

        private void equipmentDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            String str = equipmentDataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
            String idIndex = equipmentDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            data.idIndex = idIndex;
            int i = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Close();
        }

    }
    }

