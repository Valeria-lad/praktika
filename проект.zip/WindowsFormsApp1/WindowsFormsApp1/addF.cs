﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class addF : Form
    {
        private readonly string connectionString = @"Data Source=PRO_SPRINT_M\SQLEXPRESS;Initial Catalog=sam;User=Student;Password=1234;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";
        private SqlConnection sqlConnection;
        private DataTable dt = new DataTable();

        public addF()
        {
            InitializeComponent();
            this.BackColor = Color.DarkOliveGreen;

            sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();

            if (data.buf == "add")
            {
                button1.Text = "Добавить";
                this.Text = "Добавить запись";
            }
            else if (data.buf == "edit")
            {
                button1.Text = "Изменить";
                this.Text = "Изменить запись";

                LoadExistingRequest(data.idIndex);
            }
        }

        private void LoadExistingRequest(string requestId)
        {
            string query = "SELECT RequestNumber, ProblemDescription, DateCreated FROM Requests WHERE ID = @ID";

            using (SqlDataAdapter sda = new SqlDataAdapter(query, sqlConnection))
            {
                sda.SelectCommand.Parameters.AddWithValue("@ID", requestId);
                dt.Clear();
                sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    DataRow row = dt.Rows[0];
                    textBox6.Text = row["RequestNumber"].ToString();
                    textBox7.Text = row["ProblemDescription"].ToString();
                    dateTimePicker1.Value = Convert.ToDateTime(row["DateCreated"]);
                }
                else
                {
                    MessageBox.Show("Запрос не найден.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
          
            Form7 form7 = new Form7();
            form7.Show();
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox6.Text) ||
                string.IsNullOrWhiteSpace(textBox7.Text) ||
                dateTimePicker1.Value == null)
            {
                MessageBox.Show("Пожалуйста заполните все поля!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (button1.Text == "Изменить")
            {
                UpdateRequest();
            }
            else if (button1.Text == "Добавить")
            {
                AddNewRequest();
            }
        }

        private void UpdateRequest()
        {
            string updateQuery = @"
                UPDATE Requests 
                SET RequestNumber = @RequestNumber,
                    ProblemDescription = @ProblemDescription,
                    DateCreated = @DateCreated
                WHERE ID = @ID";

            try
            {
                using (SqlCommand cmd = new SqlCommand(updateQuery, sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@RequestNumber", textBox6.Text);
                    cmd.Parameters.AddWithValue("@ProblemDescription", textBox7.Text);
                    cmd.Parameters.AddWithValue("@DateCreated", dateTimePicker1.Value.Date);
                    cmd.Parameters.AddWithValue("@ID", data.idIndex);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Запись успешно изменена");
                        
                        Form7 form7 = new Form7();
                        form7.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Запрос не найден или не изменен.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddNewRequest()
        {
            string insertQuery = @"
                INSERT INTO Requests (RequestNumber, ProblemDescription, DateCreated)
                VALUES (@RequestNumber, @ProblemDescription, @DateCreated)";

            try
            {
                using (SqlCommand cmd = new SqlCommand(insertQuery, sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@RequestNumber", textBox6.Text);
                    cmd.Parameters.AddWithValue("@ProblemDescription", textBox7.Text);
                    cmd.Parameters.AddWithValue("@DateCreated", dateTimePicker1.Value.Date);

                    int rowsInserted = cmd.ExecuteNonQuery();

                    if (rowsInserted > 0)
                    {
                        MessageBox.Show("Запись успешно добавлена");
                       
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось добавить запись.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearFields()
        {
            textBox6.Clear();
            textBox7.Clear();
            dateTimePicker1.Value = DateTime.Now;
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
       
            if (sqlConnection != null && sqlConnection.State == ConnectionState.Open)
            {
                sqlConnection.Close();
            }
            base.OnFormClosing(e);
        }

           
    }
}