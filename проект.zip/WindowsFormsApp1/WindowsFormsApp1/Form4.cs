﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp1
{
    public partial class Form4 : Form
    {
        private SqlConnection sqlConnection = null;
        private DataSet dataSet = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private bool newRowAdding = false;
        private SqlCommandBuilder sqlBuilder = null;
        private DataTable dt = new DataTable();
      

        public Form4()
        {
            InitializeComponent();
            this.BackColor = Color.DarkSeaGreen;
            sqlConnection = new SqlConnection(@"Data Source = PRO_SPRINT_M\SQLEXPRESS; Initial Catalog = sam; User = Student; Password = 1234; Integrated Security = True; Encrypt = True; TrustServerCertificate = True");
            sqlConnection.Open();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "samDataSet3.FaultTypes". При необходимости она может быть перемещена или удалена.
            this.faultTypesTableAdapter.Fill(this.samDataSet3.FaultTypes);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            data.buf = "add";
           addC addС = new addC();
            addС.Show();
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            data.buf = "edit";
            addC addC = new addC();
            addC.Show();
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (data.idIndex != "")
            {
                DialogResult dialogResult = MessageBox.Show("Удалить запись?", "Удаление", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    SqlCommand cmd = new SqlCommand("DELETE FaultTypes WHERE ID = '" + data.idIndex + "'", sqlConnection);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Запись удалена");
                    this.faultTypesTableAdapter.Fill(this.samDataSet3.FaultTypes);



                }
                else if (dialogResult == DialogResult.No)
                {
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите тип оболрудования", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Close();
        }

        private void equipmentDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            String str = equipmentDataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
            String idIndex = equipmentDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            data.idIndex = idIndex;
            int i = 0;
        }
    }
}
