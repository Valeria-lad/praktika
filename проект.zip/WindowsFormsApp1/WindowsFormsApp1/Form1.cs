﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private SqlConnection sqlConnection = null;
        private DataSet dataSet = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private bool newRowAdding = false;
        private SqlCommandBuilder sqlBuilder = null;
        private DataTable dt = new DataTable();

        public Form1()
        {
            InitializeComponent();
            this.BackColor = Color.DarkSeaGreen;
            sqlConnection = new SqlConnection(@"Data Source = PRO_SPRINT_M\SQLEXPRESS; Initial Catalog = sam; User = Student; Password = 1234; Integrated Security = True; Encrypt = True; TrustServerCertificate = True");
            sqlConnection.Open();
        }


       
        private void авторыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            Hide();
        }

       

        private void книгиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Книги form3 = new Книги();
            form3.Show();
            Hide();
        }

        private void таблицыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            Hide();
        }

      

        private void button1_Click(object sender, EventArgs e)
        {
            Avtoriza avtoriza = new Avtoriza();
         
            avtoriza.Show();
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void поставщикиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            Hide();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
            Hide();
        }

        private void статусЗаявкиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
            Hide();
        }

        private void поступленияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.Show();
            Hide();
        }
    }
}
