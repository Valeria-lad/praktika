﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        private SqlConnection sqlConnection = null;
        private DataSet dataSet = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private bool newRowAdding = false;
        private SqlCommandBuilder sqlBuilder = null;
        private DataTable dt = new DataTable();
    

        public Form2()
        {
            InitializeComponent();
            this.BackColor = Color.DarkSeaGreen;
            sqlConnection = new SqlConnection(@"Data Source = PRO_SPRINT_M\SQLEXPRESS; Initial Catalog = sam; User = Student; Password = 1234; Integrated Security = True; Encrypt = True; TrustServerCertificate = True");
            sqlConnection.Open();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "samDataSet3.Users". При необходимости она может быть перемещена или удалена.
            this.usersTableAdapter3.Fill(this.samDataSet3.Users);
   
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            data.buf = "add";
            addA addA = new addA();
            addA.Show();
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {    
            data.buf = "edit";
                addA addA = new addA();
                addA.Show();
                Close();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (data.idIndex != "")
            {
                DialogResult dialogResult = MessageBox.Show("Удалить запись?", "Удаление", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    SqlCommand cmd = new SqlCommand("DELETE Users WHERE ID = '" + data.idIndex + "'", sqlConnection);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Запись удалена");

                    this.usersTableAdapter3.Fill(this.samDataSet3.Users);

                }
                else if (dialogResult == DialogResult.No)
                {
                }

            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите пользователя!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

      

        private void usersDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            String str = usersDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            String idIndex = usersDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            data.idIndex = idIndex;
            int i = 0;
        }
    }
}
